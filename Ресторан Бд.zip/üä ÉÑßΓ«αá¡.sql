Create database resstorant
go
Use resstorant
go


Create table [Staff]
(
	[Staff Id] Integer Identity NOT NULL,
	[Name] Varchar(20) NOT NULL,
	[Telephone number] Integer NOT NULL,
	[Job address] Varchar(20) NOT NULL,
	[Role] Varchar(20) NOT NULL,
	[Number of order] Integer NOT NULL,
	[Order Id] Integer NOT NULL,
	[Roles Id] Integer NOT NULL,
Primary Key ([Staff Id])
) 
go

Create table [Chief]
(
	[Chief Id] Integer Identity NOT NULL,
	[Name] Varchar(20) NOT NULL,
	[Qualification] Varchar(20) NOT NULL,
	[Job address] Varchar(20) NOT NULL,
	[Job experience] Integer NOT NULL,
Primary Key ([Chief Id])
) 
go

Create table [Product]
(
	[Product Id] Integer Identity NOT NULL,
	[Name] Varchar(20) NOT NULL,
	[Number] Integer NOT NULL,
	[Quality] Varchar(20) NOT NULL,
	[Category Id] Integer NOT NULL,
Primary Key ([Product Id])
) 
go

Create table [Drink]
(
	[Drink_Id] Integer Identity NOT NULL,
	[Name] Varchar(20) NOT NULL,
	[Number] Integer NOT NULL,
	[Quality] Varchar(20) NOT NULL,
Primary Key ([Drink_Id])
) 
go

Create table [Order]
(
	[Order Id] Integer Identity NOT NULL,
	[Name] Varchar(20)  NOT NULL,
	[Number] Integer NOT NULL,
	[Number of order] Integer NOT NULL,
	[Chief Id] Integer NOT NULL,
	[Preparing Id] Integer NOT NULL,
Primary Key ([Order Id])
) 
go

Create table [Preparing]
(
	[Preparing Id] Integer Identity NOT NULL,
	[Preparing time] Datetime NOT NULL,
	[Product Id] Integer NOT NULL,
	[Drink_Id] Integer NOT NULL,
Primary Key ([Preparing Id])
) 
go

Create table [Dish category]
(
	[Category Id] Integer Identity NOT NULL,
	[Name] Varchar(25) NOT NULL,
Primary Key ([Category Id])
) 
go

Create table [Roles]
(
	[Roles Id] Integer Identity NOT NULL,
	[Name] Varchar(25) NOT NULL,
Primary Key ([Roles Id])
) 
go


Alter table [Order] add  foreign key([Chief Id]) references [Chief] ([Chief Id])  on update no action on delete no action 
go
Alter table [Preparing] add  foreign key([Product Id]) references [Product] ([Product Id])  on update no action on delete no action 
go
Alter table [Preparing] add  foreign key([Drink_Id]) references [Drink] ([Drink_Id])  on update no action on delete no action 
go
Alter table [Staff] add  foreign key([Order Id]) references [Order] ([Order Id])  on update no action on delete no action 
go
Alter table [Order] add  foreign key([Preparing Id]) references [Preparing] ([Preparing Id])  on update no action on delete no action 
go
Alter table [Product] add  foreign key([Category Id]) references [Dish category] ([Category Id])  on update no action on delete no action 
go
Alter table [Staff] add  foreign key([Roles Id]) references [Roles] ([Roles Id])  on update no action on delete no action 
go