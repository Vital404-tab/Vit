Create database Restorant
go

use Restorant
go

create table products_category(
product_category_id integer primary key identity not null,
[name] varchar(30)
)
go
create table products(
id_product integer primary key identity not null,
[name] varchar(30),
product_category_id integer
) 
go

create table roles(
 id_role integer primary key identity not null,
 title varchar(20)
 )
 go
 create table users(
 id_user integer primary key identity not null,
 id_role integer,
 [last_name] varchar(30),
 [first_name] varchar(30),
 [middle_name] varchar(30),
 [login] varchar(30),
 [password] varchar(30)
 )
 go
create table categories(
 id_category integer primary key identity not null,
 title varchar(50)
 )
 go
 create table dishes(
 id_dish integer primary key identity not null,
 title varchar(50),
 id_category integer,
 [description] varchar(255),
 )
 go
 create table composition(
	id_dishes integer,
	id_product integer
	)
go
 create table menu_position(
 id_menu_position integer primary key identity not null,
 id_dishes integer,
 price decimal(37,2)
 )
 go
 create table order_status(
 id_order_status integer primary key identity not null,
 title varchar(50)
 )
 go
 create table orders(
 id_order integer primary key identity not null,
 id_menu_position integer,
 id_status integer,
 id_user integer,
 amount integer,
 [description] varchar(255)
 )
 go
 alter table users add foreign key(id_role) references roles(id_role)
 go
 alter table dishes add foreign key(id_category) references categories(id_category)
 go
 alter table menu_position add foreign key(id_dishes) references dishes(id_dish) 
 go
 alter table orders add foreign key(id_status) references order_status(id_order_status)
 go
 alter table orders add foreign key(id_menu_position) references menu_position(id_menu_position)
 go
  alter table products add foreign key(product_category_id ) references products_category(product_category_id)
 go
 alter table composition add foreign key(id_product) references products(id_product)
 go
  alter table composition add foreign key(id_dishes) references dishes(id_dish)
  go
  alter table orders add foreign key(id_user) references users(id_user)

  drop table products